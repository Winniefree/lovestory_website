
function checkPassword() {
    const password = document.getElementById('password').value;
    if (password === "&AWxR7" || password === "Amor7:927∞") {
        alert("Welcome, love!");
    } else {
        alert("Incorrect password, please try again.");
    }
}
